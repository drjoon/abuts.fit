using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritGeometryBase;

[ComImport]
[CompilerGenerated]
[Guid("BA797E8F-0CD8-4C15-BCB3-D76E6A0DCC95")]
[TypeIdentifier]
public interface ComGeoBoundUnbound : ComGeoBounded
{
}
