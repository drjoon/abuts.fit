using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritGeometryBase;

[ComImport]
[CompilerGenerated]
[Guid("A456D7B3-3EED-45CD-A202-36371B7C8400")]
[TypeIdentifier]
public interface ComGeoBounded : ComGeoBase
{
}
