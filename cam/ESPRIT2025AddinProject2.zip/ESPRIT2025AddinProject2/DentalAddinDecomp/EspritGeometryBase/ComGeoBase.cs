using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritGeometryBase;

[ComImport]
[CompilerGenerated]
[Guid("F92F1A0A-9708-44FA-A894-61343586145A")]
[TypeIdentifier]
public interface ComGeoBase
{
}
