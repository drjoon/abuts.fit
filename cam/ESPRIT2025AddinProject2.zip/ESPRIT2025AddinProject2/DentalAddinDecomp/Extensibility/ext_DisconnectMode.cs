using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Extensibility;

[CompilerGenerated]
[Guid("289E9AF2-4973-11D1-AE81-00A0C90F26F4")]
[TypeIdentifier("ac0714f2-3d04-11d1-ae7d-00a0c90f26f4", "Extensibility.ext_DisconnectMode")]
public enum ext_DisconnectMode
{
	ext_dm_HostShutdown,
	ext_dm_UserClosed,
	ext_dm_UISetupComplete,
	ext_dm_SolutionClosed
}
