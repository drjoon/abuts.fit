using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Extensibility;

[CompilerGenerated]
[Guid("289E9AF1-4973-11D1-AE81-00A0C90F26F4")]
[TypeIdentifier("ac0714f2-3d04-11d1-ae7d-00a0c90f26f4", "Extensibility.ext_ConnectMode")]
public enum ext_ConnectMode
{
	ext_cm_AfterStartup,
	ext_cm_Startup,
	ext_cm_External,
	ext_cm_CommandLine,
	ext_cm_Solution,
	ext_cm_UISetup
}
