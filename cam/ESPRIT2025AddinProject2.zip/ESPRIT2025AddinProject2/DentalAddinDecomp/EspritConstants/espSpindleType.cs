using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritConstants;

[CompilerGenerated]
[TypeIdentifier("b7984a92-b24c-4128-945c-c9d421ceb678", "EspritConstants.espSpindleType")]
public enum espSpindleType
{
	espSpindleMain = 1,
	espSpindleSub,
	espSpindleTurretMounted
}
