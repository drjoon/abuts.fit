using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritConstants;

[CompilerGenerated]
[TypeIdentifier("b7984a92-b24c-4128-945c-c9d421ceb678", "EspritConstants.espExtremityType")]
public enum espExtremityType
{
	espExtremityStart,
	espExtremityMiddle,
	espExtremityEnd
}
