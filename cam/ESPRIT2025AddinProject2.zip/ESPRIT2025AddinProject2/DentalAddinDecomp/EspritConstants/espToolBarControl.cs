using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritConstants;

[CompilerGenerated]
[TypeIdentifier("b7984a92-b24c-4128-945c-c9d421ceb678", "EspritConstants.espToolBarControl")]
public enum espToolBarControl
{
	espToolBarControlUnknown = -1,
	espToolBarControlSeparator,
	espToolBarControlButton
}
