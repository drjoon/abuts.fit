namespace DentalAddin
{
    internal struct RECT
    {
        internal int X1;

        internal int Y1;

        internal int X2;

        internal int Y2;
    }
}
