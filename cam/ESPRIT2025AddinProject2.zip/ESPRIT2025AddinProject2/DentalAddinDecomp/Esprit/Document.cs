using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("E8F73F35-CA98-41CE-8EE7-570E9365EBF8")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface Document : IDualDocument, _IDocumentEvents_Event
{
}
