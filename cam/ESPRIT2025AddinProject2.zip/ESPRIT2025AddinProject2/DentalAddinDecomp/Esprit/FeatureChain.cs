using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("5ABE8E93-8A1E-443E-8824-3CFDC9D60325")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface FeatureChain : IFeatureChain
{
}
