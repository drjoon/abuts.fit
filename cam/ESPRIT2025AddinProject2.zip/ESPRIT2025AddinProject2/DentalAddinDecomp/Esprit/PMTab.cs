using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("FCB4C85E-3FEC-4849-A0D5-A29E9130507D")]
[TypeIdentifier]
public interface PMTab : IPMTab
{
}
