using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("AEE41744-FDF9-47FB-90B2-72D0A90B0443")]
[TypeIdentifier]
public interface IHeadSpindleTurret
{
}
