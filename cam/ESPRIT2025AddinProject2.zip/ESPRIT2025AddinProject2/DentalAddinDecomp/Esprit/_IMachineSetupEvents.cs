using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("BC81CEAA-CC10-44E8-AE8B-07BCD3563851")]
[InterfaceType(2)]
[TypeIdentifier]
public interface _IMachineSetupEvents
{
}
