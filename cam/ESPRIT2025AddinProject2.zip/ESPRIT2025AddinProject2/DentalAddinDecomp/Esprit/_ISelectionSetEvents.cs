using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("CAC3D4C4-C972-469F-9F7A-C7245F685D7A")]
[InterfaceType(2)]
[TypeIdentifier]
public interface _ISelectionSetEvents
{
}
