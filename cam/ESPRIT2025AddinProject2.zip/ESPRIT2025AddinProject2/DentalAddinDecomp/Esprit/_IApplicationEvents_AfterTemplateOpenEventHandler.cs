using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[CompilerGenerated]
[TypeIdentifier("bbd2ce70-67ec-11d0-a953-006097130612", "Esprit._IApplicationEvents_AfterTemplateOpenEventHandler")]
public delegate void _IApplicationEvents_AfterTemplateOpenEventHandler([In][MarshalAs(UnmanagedType.BStr)] string FileName);
