using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("9A26FB2A-3332-457E-BE60-6F7E4CC3965A")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface FreeFormFeatures : IFreeFormFeatures
{
}
