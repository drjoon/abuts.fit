using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("DE29E857-A27A-40F9-9961-B094A31C03DF")]
[TypeIdentifier]
public interface SelectionSet : ISelectionSet, _ISelectionSetEvents_Event
{
}
