using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("BFFBB58D-B8F5-4794-A3EF-216222C64C92")]
[TypeIdentifier]
public interface LatheMachineSetup : ILatheMachineSetup, _IMachineSetupEvents_Event
{
}
