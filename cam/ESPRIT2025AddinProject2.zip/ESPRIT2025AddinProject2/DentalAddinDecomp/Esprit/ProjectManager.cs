using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("69C7DFAD-DC52-4E7C-9320-1F1D5AC2875C")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface ProjectManager : IProjectManager
{
}
