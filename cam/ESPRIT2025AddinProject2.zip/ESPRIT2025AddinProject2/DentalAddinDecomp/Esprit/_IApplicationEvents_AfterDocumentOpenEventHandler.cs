using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[CompilerGenerated]
[TypeIdentifier("bbd2ce70-67ec-11d0-a953-006097130612", "Esprit._IApplicationEvents_AfterDocumentOpenEventHandler")]
public delegate void _IApplicationEvents_AfterDocumentOpenEventHandler([In][MarshalAs(UnmanagedType.BStr)] string FileName);
