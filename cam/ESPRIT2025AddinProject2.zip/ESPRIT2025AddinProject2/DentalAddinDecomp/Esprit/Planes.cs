using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("D06DC678-EB2A-4F5B-A0B2-363E355FECF3")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface Planes : IPlanes
{
}
