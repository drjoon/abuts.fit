using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("209B922B-0EB1-4E1F-9A38-F4272B49E752")]
[TypeIdentifier]
public interface FeatureChains : IFeatureChains
{
}
