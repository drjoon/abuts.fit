using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("E449A63A-468F-44F8-B179-ED15FE3DC42E")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface GraphicsCollection : IGraphicsCollection, _IGraphicEvents_Event
{
}
