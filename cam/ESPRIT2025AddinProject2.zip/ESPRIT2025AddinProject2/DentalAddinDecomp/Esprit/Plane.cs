using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("364CB1C4-8CBC-4654-A1AB-E516E5DD2A87")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface Plane : IPlane
{
}
