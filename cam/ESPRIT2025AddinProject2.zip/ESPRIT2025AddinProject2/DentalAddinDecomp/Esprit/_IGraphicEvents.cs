using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[InterfaceType(2)]
[Guid("BCFACA51-3230-4700-A6A5-A150113E8612")]
[TypeIdentifier]
public interface _IGraphicEvents
{
}
