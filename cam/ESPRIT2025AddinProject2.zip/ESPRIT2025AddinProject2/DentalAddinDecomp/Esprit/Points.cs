using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("6B5C1181-00AF-4815-A6CE-16F6BC1B87D9")]
[TypeIdentifier]
public interface Points : IPoints
{
}
