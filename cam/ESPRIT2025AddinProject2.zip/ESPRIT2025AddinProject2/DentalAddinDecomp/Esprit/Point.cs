using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("F325553B-9037-4C99-B736-964A31DEA03A")]
[TypeIdentifier]
public interface Point : IPoint
{
}
