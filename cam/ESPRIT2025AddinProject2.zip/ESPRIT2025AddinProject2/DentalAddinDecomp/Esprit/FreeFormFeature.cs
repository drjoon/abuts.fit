using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("588C8065-2906-4FD1-876C-68CC9519F088")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface FreeFormFeature : IFreeFormFeature
{
}
