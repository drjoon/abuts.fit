using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("65845457-7C7C-4D09-AF0E-B3F58E144A6F")]
[TypeIdentifier]
public interface Layer : ILayer
{
}
