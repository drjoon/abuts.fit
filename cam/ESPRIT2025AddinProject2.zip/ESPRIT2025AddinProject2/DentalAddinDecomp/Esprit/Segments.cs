using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("2769CD06-6B14-4D43-853A-E765CA403C54")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface Segments : ISegments
{
}
