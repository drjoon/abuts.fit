using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("0F8C53C2-371D-44A6-8B4F-F5632D9CC574")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface FeatureRecognition : IFeatureRecognition
{
}
