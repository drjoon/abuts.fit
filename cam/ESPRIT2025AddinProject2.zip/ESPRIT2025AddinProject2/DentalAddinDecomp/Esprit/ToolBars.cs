using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("6368EAFE-ACE6-4D74-A55F-EF7356C80A21")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface ToolBars : IToolBars
{
}
