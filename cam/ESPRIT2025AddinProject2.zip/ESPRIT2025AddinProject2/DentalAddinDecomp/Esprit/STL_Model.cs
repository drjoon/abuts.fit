using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("E9F134A9-D6CB-4BF1-B3CD-5B34EAAF4D06")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface STL_Model : ISTL_Model
{
}
