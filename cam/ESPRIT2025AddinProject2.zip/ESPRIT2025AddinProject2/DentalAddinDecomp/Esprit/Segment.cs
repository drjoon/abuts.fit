using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("F4C12C01-CCE2-408C-9B22-74A15219E02B")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface Segment : ISegment
{
}
