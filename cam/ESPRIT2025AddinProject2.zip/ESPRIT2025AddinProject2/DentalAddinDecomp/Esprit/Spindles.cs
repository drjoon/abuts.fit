using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("C7CC35CD-A784-431F-84B9-47E3995034B0")]
[TypeIdentifier]
public interface Spindles : ISpindles
{
}
