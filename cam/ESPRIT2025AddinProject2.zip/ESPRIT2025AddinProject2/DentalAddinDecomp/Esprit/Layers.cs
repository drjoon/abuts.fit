using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("5B3577CA-AB75-40AF-8FF1-9E0C9982EAEF")]
[TypeIdentifier]
public interface Layers : ILayers
{
}
