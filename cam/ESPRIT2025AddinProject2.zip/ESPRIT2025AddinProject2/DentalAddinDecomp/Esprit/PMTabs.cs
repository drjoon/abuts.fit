using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("4152E522-2B36-46DB-9BDF-F7C699225858")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface PMTabs : IPMTabs
{
}
