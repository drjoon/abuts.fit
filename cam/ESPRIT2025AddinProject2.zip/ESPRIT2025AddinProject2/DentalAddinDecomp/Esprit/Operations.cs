using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("FBBA7A9B-5916-46C5-AFAA-18FDCF6B59F2")]
[TypeIdentifier]
public interface Operations : IOperations, _IOperationEvents_Event
{
}
