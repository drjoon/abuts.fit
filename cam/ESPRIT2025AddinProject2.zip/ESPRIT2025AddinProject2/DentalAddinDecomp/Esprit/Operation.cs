using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("DD69EDA0-293A-416A-B801-4EAFEC44D434")]
[TypeIdentifier]
public interface Operation : IOperation
{
}
