using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("DA611C72-D3C6-4A2B-B16A-80562EEFF042")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface Arc : IArc
{
}
