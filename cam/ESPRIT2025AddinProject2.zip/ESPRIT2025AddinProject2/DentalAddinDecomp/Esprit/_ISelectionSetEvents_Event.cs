using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[ComEventInterface(typeof(_ISelectionSetEvents), typeof(_ISelectionSetEvents))]
[TypeIdentifier("bbd2ce70-67ec-11d0-a953-006097130612", "Esprit._ISelectionSetEvents_Event")]
public interface _ISelectionSetEvents_Event
{
}
