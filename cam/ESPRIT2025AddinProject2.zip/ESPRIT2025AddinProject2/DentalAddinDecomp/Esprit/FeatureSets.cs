using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("64D64494-84C8-4699-A6D8-767270B3821D")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface FeatureSets : IFeatureSets
{
}
