using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[ComEventInterface(typeof(_IGraphicEvents), typeof(_IGraphicEvents))]
[TypeIdentifier("bbd2ce70-67ec-11d0-a953-006097130612", "Esprit._IGraphicEvents_Event")]
public interface _IGraphicEvents_Event
{
}
