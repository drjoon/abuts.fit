using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("7973FBC5-0796-4F77-BE66-2419F0EFA988")]
[TypeIdentifier]
public interface FeatureSet : IFeatureSet
{
}
