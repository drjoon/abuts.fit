using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("DB1BB12A-BBE5-46E7-9E4A-08C44954940D")]
[TypeIdentifier]
public interface IFeature : IGraphicObject
{
}
