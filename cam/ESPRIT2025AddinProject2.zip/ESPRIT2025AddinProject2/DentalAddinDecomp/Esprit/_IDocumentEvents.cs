using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[InterfaceType(2)]
[Guid("7AA04FEC-DA46-4D11-BF2E-0794A97D7617")]
[TypeIdentifier]
public interface _IDocumentEvents
{
}
