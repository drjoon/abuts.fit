using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("69663F38-EE6F-409F-9540-30E15ACD8E0A")]
[TypeIdentifier]
public interface Application : IDualApplication, _IApplicationEvents_Event
{
}
