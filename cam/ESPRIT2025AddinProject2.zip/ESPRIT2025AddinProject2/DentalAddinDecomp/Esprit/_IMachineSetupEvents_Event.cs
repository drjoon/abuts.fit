using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[ComEventInterface(typeof(_IMachineSetupEvents), typeof(_IMachineSetupEvents))]
[TypeIdentifier("bbd2ce70-67ec-11d0-a953-006097130612", "Esprit._IMachineSetupEvents_Event")]
public interface _IMachineSetupEvents_Event
{
}
