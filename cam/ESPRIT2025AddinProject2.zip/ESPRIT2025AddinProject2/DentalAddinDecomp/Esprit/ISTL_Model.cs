using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("E9F134A9-D6CB-4BF1-B3CD-5B34EAAF4D06")]
[TypeIdentifier]
public interface ISTL_Model : IGraphicObject
{
}
