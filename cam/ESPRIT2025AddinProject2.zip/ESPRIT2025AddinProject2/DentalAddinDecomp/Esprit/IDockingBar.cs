using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("8F303B81-3247-491D-90B0-6E41FB3FEA62")]
[TypeIdentifier]
public interface IDockingBar
{
}
