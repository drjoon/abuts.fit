using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("A14AFEC4-43D3-4604-BC13-C8010DEE744A")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface OutputWindow : IOutputWindow
{
}
