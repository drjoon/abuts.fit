using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("6621B3B9-40CA-4267-AD9B-589C9C002088")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface Arcs : IArcs
{
}
