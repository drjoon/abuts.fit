using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("9142F47D-6D0E-4DF3-A85E-E13ACD17EB31")]
[InterfaceType(2)]
[TypeIdentifier]
public interface _IOperationEvents
{
}
