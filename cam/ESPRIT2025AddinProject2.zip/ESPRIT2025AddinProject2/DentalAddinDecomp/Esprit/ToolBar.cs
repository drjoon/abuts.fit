using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("19B93A94-9401-4DBA-93C3-326967C6649E")]
[TypeIdentifier]
public interface ToolBar : IToolBar
{
}
