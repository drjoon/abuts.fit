using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("5EA6E570-9CA8-4FA9-8ABE-EE03CBF6F1D8")]
[TypeIdentifier]
public interface Window : IWindow
{
}
