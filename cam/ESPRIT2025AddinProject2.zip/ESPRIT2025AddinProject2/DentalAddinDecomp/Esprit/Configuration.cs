using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("51E3AF7E-C263-4C68-8934-C002281B1013")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface Configuration : IConfiguration
{
}
