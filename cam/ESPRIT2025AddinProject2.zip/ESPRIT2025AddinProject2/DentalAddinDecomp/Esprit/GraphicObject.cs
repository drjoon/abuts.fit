using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("AB4D5FF3-17FB-4AE6-9BBB-D2FE25A02693")]
[TypeIdentifier]
public interface GraphicObject : IGraphicObject
{
}
