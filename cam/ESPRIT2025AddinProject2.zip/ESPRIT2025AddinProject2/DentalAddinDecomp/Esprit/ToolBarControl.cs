using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("A10BBDE2-722F-4687-98A4-C6A6A675C3CA")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface ToolBarControl : IToolBarControl
{
}
