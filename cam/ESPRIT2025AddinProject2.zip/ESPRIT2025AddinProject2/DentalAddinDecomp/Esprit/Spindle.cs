using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("A0CF3A4A-24F6-4905-9126-C8A2581339A4")]
[TypeIdentifier]
public interface Spindle : ISpindle
{
}
