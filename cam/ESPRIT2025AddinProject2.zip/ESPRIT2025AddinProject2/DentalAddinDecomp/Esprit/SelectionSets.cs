using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("1055CDA8-5BFD-40DB-A7BA-6AD82A8CEABF")]
[TypeIdentifier]
public interface SelectionSets : ISelectionSets
{
}
