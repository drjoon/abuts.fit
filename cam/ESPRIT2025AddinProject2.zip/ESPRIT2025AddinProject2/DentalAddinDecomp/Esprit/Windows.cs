using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Esprit;

[ComImport]
[CompilerGenerated]
[Guid("0426E912-B61D-42BF-AA6D-A4344CEFFECE")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface Windows : IWindows
{
}
