using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritGeometryRoutines;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("74E05F3D-2279-4FA0-BB75-9FA7EB686F1D")]
[TypeIdentifier]
public interface GeoUtility : IGeoUtility
{
}
