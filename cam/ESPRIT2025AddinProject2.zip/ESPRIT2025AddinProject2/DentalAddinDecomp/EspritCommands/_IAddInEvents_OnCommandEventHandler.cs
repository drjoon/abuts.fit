using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritCommands;

[CompilerGenerated]
[TypeIdentifier("a300048b-1b1f-4e73-879b-94d6a4e82171", "EspritCommands._IAddInEvents_OnCommandEventHandler")]
public delegate void _IAddInEvents_OnCommandEventHandler([In] int Cookie, [In] int UserId);
