using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritCommands;

[ComImport]
[CompilerGenerated]
[Guid("F117077A-2C8D-450F-92B2-CD1A0D382609")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface AddIn : IAddIn, _IAddInEvents_Event
{
}
