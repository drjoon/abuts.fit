using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritMenus;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("7DD7DD1B-9ED0-4293-943E-F4FE3C748303")]
[TypeIdentifier]
public interface MenuItem : IMenuItem
{
}
