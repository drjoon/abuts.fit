using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritMenus;

[ComImport]
[CompilerGenerated]
[Guid("DC8EE712-27AC-4868-A387-5B57D3B901B6")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface Menu : IMenu
{
}
