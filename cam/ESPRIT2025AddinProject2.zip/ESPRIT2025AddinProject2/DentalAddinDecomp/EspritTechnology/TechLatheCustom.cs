using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("2DCD3B1B-62EF-4227-BC9C-30758EE905D7")]
[TypeIdentifier]
public interface TechLatheCustom : ITechLatheCustom
{
}
