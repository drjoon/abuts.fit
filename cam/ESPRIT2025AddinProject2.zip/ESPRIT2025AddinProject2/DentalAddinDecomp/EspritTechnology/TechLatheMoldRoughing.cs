using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[Guid("C826CAB3-CABB-48F5-BACF-50E7DF37E5C6")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface TechLatheMoldRoughing : ITechLatheMoldRoughing
{
}
