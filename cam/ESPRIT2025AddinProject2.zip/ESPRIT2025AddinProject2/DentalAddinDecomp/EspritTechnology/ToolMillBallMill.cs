using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("541DBD29-C703-4E90-959A-EDFA088FB6DC")]
[TypeIdentifier]
public interface ToolMillBallMill : IToolMillBallMill
{
}
