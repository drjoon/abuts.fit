using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[Guid("A4179D37-65DA-43EE-A60E-58A090F45717")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface TechLatheMoldParallelPlanes : ITechLatheMoldParallelPlanes
{
}
