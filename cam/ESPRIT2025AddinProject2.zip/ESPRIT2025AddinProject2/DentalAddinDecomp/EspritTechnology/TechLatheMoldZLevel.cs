using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[Guid("810C35D2-3B72-40F6-B645-EC9E4D72E31A")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface TechLatheMoldZLevel : ITechLatheMoldZLevel
{
}
