using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[Guid("2DCD3B1B-62EF-4227-BC9C-30758EE905D7")]
[TypeIdentifier]
public interface ITechLatheCustom
{
}
