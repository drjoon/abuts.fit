using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("BC3D30D9-F9A8-48E4-A413-3482D9C08677")]
[TypeIdentifier]
public interface Parameter : IParameter, _IParameterEvents_Event
{
}
