using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("9F6FD304-7FBF-4D8E-B538-D42AAE3DB2D3")]
[TypeIdentifier]
public interface TechLatheMillContour1 : ITechLatheMillContour1
{
}
