using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("32C8660C-E4B5-4FCF-92A8-1CBCA50B3641")]
[TypeIdentifier]
public interface TechnologyUtility : ITechnologyUtility, _ITechnologyUtilityEvents_Event
{
}
