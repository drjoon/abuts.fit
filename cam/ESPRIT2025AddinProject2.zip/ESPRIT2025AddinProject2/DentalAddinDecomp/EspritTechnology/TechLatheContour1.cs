using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("9F678EB1-2181-4F54-BF5E-723304A40510")]
[TypeIdentifier]
public interface TechLatheContour1 : ITechLatheContour1
{
}
