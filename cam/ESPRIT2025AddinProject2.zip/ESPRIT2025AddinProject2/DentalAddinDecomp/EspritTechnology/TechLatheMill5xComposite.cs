using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[Guid("C597FA13-134D-4647-B226-CC6AF2744F5D")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface TechLatheMill5xComposite : ITechLatheMill5xComposite
{
}
