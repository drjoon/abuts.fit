using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[Guid("F0A118CB-1BAE-4F72-9C98-D42915C1F1A2")]
[InterfaceType(2)]
[TypeIdentifier]
public interface _IParameterEvents
{
}
