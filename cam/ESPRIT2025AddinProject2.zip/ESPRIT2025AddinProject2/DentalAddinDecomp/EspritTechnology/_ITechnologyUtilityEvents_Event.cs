using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[ComEventInterface(typeof(_ITechnologyUtilityEvents), typeof(_ITechnologyUtilityEvents))]
[TypeIdentifier("56893da1-c5c2-41fd-ac09-2e90f4b2ff30", "EspritTechnology._ITechnologyUtilityEvents_Event")]
public interface _ITechnologyUtilityEvents_Event
{
}
