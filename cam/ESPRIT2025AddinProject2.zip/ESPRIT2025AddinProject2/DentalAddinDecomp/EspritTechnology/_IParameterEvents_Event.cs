using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[ComEventInterface(typeof(_IParameterEvents), typeof(_IParameterEvents))]
[TypeIdentifier("56893da1-c5c2-41fd-ac09-2e90f4b2ff30", "EspritTechnology._IParameterEvents_Event")]
public interface _IParameterEvents_Event
{
}
