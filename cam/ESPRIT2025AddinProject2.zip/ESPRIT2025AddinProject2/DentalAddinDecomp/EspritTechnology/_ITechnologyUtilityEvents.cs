using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[InterfaceType(2)]
[Guid("57503968-B971-4C05-B44E-F9634EAB0E78")]
[TypeIdentifier]
public interface _ITechnologyUtilityEvents
{
}
