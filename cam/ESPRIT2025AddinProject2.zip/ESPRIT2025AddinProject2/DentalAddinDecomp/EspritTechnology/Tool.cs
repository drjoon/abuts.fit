using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[Guid("CEBCFC53-F992-4CD6-946F-C2E6ED9FEC91")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface Tool : ITool
{
}
