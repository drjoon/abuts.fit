using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace EspritTechnology;

[ComImport]
[CompilerGenerated]
[Guid("E36BC9C4-3AA7-440C-BDD3-A96D86AF1EF4")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface TechLatheMold3dContour : ITechLatheMold3dContour
{
}
