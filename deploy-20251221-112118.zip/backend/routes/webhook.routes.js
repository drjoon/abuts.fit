import { Router } from "express";
const router = Router();

export default router;
